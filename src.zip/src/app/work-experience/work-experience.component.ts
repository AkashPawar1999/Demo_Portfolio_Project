import { Component, OnInit } from '@angular/core';
import { WorkExperience } from '../models/models';

@Component({
  selector: 'app-work-experience',
  templateUrl: './work-experience.component.html',
  styleUrls: ['./work-experience.component.css']
})
export class WorkExperienceComponent implements OnInit{

  workExpList: WorkExperience[] = [
    {
      role: "Software Developer",
    company: "Agiliad Technology",
    duration: "4 year",
    description: [
      'worked with multiple teams to develope web and desktop appilcation.',
      'worked on different technology(SQL,Html,CSS,JS).'
    ]
    },
    {
      role: "Jr Software Developer",
    company: "Harman Technology",
    duration: "1 year",
    description: [
      'worked with multiple teams to develope machines appilcation.',
      'worked on different technology(AFT, MFT).'
    ]
    }
  ]

  ngOnInit(): void {}
}
